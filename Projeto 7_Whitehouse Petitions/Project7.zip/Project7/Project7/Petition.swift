//
//  Petition.swift
//  Project7
//
//  Created by Matheus  Torres on 09/07/24.
//

import Foundation

struct Petition: Codable {
    var title: String
    var body: String
    var signatureCount: Int
}
