//
//  Petitions.swift
//  Project7
//
//  Created by Matheus  Torres on 09/07/24.
//

import Foundation

struct Petitions: Codable {
    var results: [Petition]
}
