//
//  InitialViewController.swift
//  Project5
//
//  Created by Matheus  Torres on 01/07/24.
//

import UIKit

class InitialViewController: UIViewController {
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
        setupButtons()
    }
    
    //MARK: - Método de Configuração
    func setupView() {
        view.backgroundColor = .white
    }
    
    func setupButtons() {
        let startButton = createButton(title: "Start Game", action: #selector(startGame))
        let quitButton = createButton(title: "Quit", action: #selector(quitApp))
        
        let stackView = UIStackView(arrangedSubviews: [startButton, quitButton])
        stackView.axis = .vertical
        stackView.spacing = 20
        stackView.alignment = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
    
    func createButton(title: String, action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        button.addTarget(self, action: action, for: .touchUpInside)
        return button
    }
    
    @objc func startGame() {
        let viewController = ViewController()
        navigationController?.pushViewController(viewController, animated: true)
    }
    
    @objc func quitApp() {
        UIControl().sendAction(#selector(NSXPCConnection.suspend), to: UIApplication.shared, for: nil)
    }
}
