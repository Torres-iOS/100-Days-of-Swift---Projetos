# Project 4 - Simple Web Browser

### Descrição

Este projeto é um navegador web simples para iOS, desenvolvido com Swift e WKWebView. Ele permite aos usuários navegar na web com funcionalidades básicas de um navegador.

**Funcionalidades** 

•  Carregamento de páginas web

•  Navegação avançar e voltar

•  Atualização da página

•  Inserção de URLs manualmente

**Tecnologias**

•  Swift

•  UIKit

• WKWebView

**Requisitos**

•  Xcode 12 ou superior

•  iOS 14.0 ou superior

  

**Instalação**
 

1.  Clone este repositório:

```git clone https://github.com/Torres-iOS/Project-4_Simple-Web-Browser.git```

2.  Abra o projeto no Xcode.

3.  Conecte um dispositivo iOS ou use o simulador.

4.  Compile e execute o projeto.

  

**Uso**

  

1.  Insira a URL na barra de endereços.

2.  Use os botões para navegar entre as páginas ou atualizar a página atual.
